const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

exports.run = (client, message, params) => {
  const embedyardim = new Discord.RichEmbed()
  .setTitle("Komutlar")
  .setDescription('')
  .setColor(0x00ffff)
  .addField("**Müzik Komutları:**", `!p Müzik Çalar \n!stop Müziği Durdurur \n!ses Ses Düzeyini Ayarlar\n!gir Odaya Girer\n!kuyruk Sıradaki Şarkıları Gösterir\n!s Şarkıyı geçer!\n!resume Şarkıyı devam ettirir!\n!çalan Çalan müziği gösterir!\n!sıra Sıradaki müzikleri gösterir!`)
  if (!params[0]) {
    const commandNames = Array.from(client.commands.keys());
    const longest = commandNames.reduce((long, str) => Math.max(long, str.length), 0);
    message.channel.send(embedyardim);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.author.send('asciidoc', `= ${command.help.name} = \n${command.help.description}\nDoğru kullanım: ` + prefix + `${command.help.usage}`);
    }
  }
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['m', 'mazük', 'müzük', 'müzik'],
  kategori: 'Ayarlar',
  permLevel: 0
};

exports.help = {
  name: 'müzik',
  description: 'Tüm komutları gösterir.',
  usage: 'Müzik [komut]'
};