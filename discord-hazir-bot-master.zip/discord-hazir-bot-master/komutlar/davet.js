const Discord = require('discord.js');

exports.run = (client, message, args) => {
  const embed = new Discord.RichEmbed()
  
.setColor("RANDOM")
.setAuthor(client.user.username, client.user.avatarURL)
.setDescription("[Beni Sunucuna Almak İçin Tıkla](https://discordapp.com/oauth2/authorize?client_id=668937362411094041&scope=bot&permissions=8) | Flex Bot 2020")
.setFooter(`${message.author.username} Tarafından İstendi.`, message.author.displayAvatarURL)
  
  
  return message.channel.send(embed);
};


exports.conf = {
  enabled: true,
  aliases: ['invite'],
  kategori: "bot",
  permLevel: 0,
};    

exports.help = {
  name: "davet",
  description: "Bot Davet Linkini Gösterir",
  usage: "davet"
};