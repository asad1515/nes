const config = {
  "token": "NjY4OTM3MzYyNDExMDk0MDQx.XiYjpA.DBtKId8Y9NMPnXBvD_5IIDXEFV4",
  "sahip": "324201796945838091",

  "dashboard" : {
    "oauthSecret": "jGEroIYayQ-qSGt2_WORk-O6A3GLCQ2b", // This is the `client` secret in your bot application page.
    "callbackURL": "https://flexbotofficial.glitch.me/callback",
    "sessionSecret": "Flexbot Dashboard",
    "domain": "https://flexbotofficial.glitch.me",
    "port": 8000
  },
};

module.exports = config;